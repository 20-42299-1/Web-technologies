<?php
$vegProduct =
"<?xml version='1.0' encoding='UTF-8'?>
<note>
<p1>July:</p1>
<type>Vegetable price per kg</type>

</note>";
?>
<div style="background-color:white">
<div style="background-color:RGB(46,139,87)">
<h1 style="color:white;font-size:30px">
Original market price:
<?php
$xml=simplexml_load_string($vegProduct) or die("Error: Cannot create object");
print_r($vegProduct);
?>
</h1>
</div>

<?php
$vege =
"<?xml version='1.0' encoding='UTF-8'?>
<note>
<veg1>Potato: 40tk</veg1>
<veg2>Cucumber: 30</veg2>
<veg3>Cabbage: 80tk</veg3>
<veg4>Carrot: 35tk</veg4>
<veg5>Tomato: 20tk</veg5>
<veg6>Brinjal: 60tk</veg6>
<veg7>Broccoli: 40tk</veg7>
<veg8>Lady's finger: 80tk</veg8>
<veg9>Bottle Gourd: 160tk</veg9>
<veg10>Bitter Gourd: 110tk</veg10>
<veg11>Capsicum: 100tk</veg11>
</note>";
?>
<b>Vegetable:</b><br>
<?php
$xml=simplexml_load_string($vege) or die("Error: Cannot create object");
print_r($vege);
?>
<br><br>
</div>

<?php
$fruitProduct =
"<?xml version='1.0' encoding='UTF-8'?>
<note>
<p1>July:</p1>
<type>Fruits price per kg</type>

</note>";
?>
<div style="background-color:white">
<div style="background-color:RGB(46,139,87)">
<h1 style="color:white;font-size:30px">
Original market price:
<?php
$xml=simplexml_load_string($firstProduct) or die("Error: Cannot create object");
print_r($fruitProduct);
?>
</h1>
</div>

<?php
$fruits =
"<?xml version='1.0' encoding='UTF-8'?>
<note>
<fruit1>Apple: 220tk</fruit1>
<fruit2>Banana 90tk</fruit2>
<fruit3>Orange: 160tk</fruit3>
<fruit4>Mango: 140tk</fruit4>
<fruit5>Grapes: 130tk</fruit5>
<fruit6>Pineapple: 60tk</fruit6>
<fruit7>Strawberry: 270tk</fruit7>
<fruit8>Jackfruit:120tk</fruit8>
<fruit9>Papaya: 80tk</fruit9>
<fruit10>Coconut:40tk</fruit10>
<fruit11>Pear: 100tk</fruit11>
</note>";
?>
<b>Most Common Answer:</b><br>
<?php
$xml=simplexml_load_string($fruits) or die("Error: Cannot create object");
print_r($fruits);
?>
<br><br>
</div>
