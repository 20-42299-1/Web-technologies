<html>
<body>
<?php
session_start();
?>
<div style="background-color:white">
    <a href="../view/Home page.php"><img src="../view/logo.jpg" height=130 style="float:left;" ></a>
	 <h3 style="float: right; color: RGB(46,139,87)"><br><br><a href="../view/agriculturist profile.php"><h3 style="color:RGB(46,139,87);float: right;"><u> <?php echo "welcome,". $_SESSION["uname"] ; ?></u></h3></h3></a>
	 <br><h1 style= "color: cmyk(0,0,0,1);font-size:30px;font-family:'public sans'"> <b>AGRICULTURAL GAIN </b> </h1>
    <h4 style= "color:RGB(105,105,105) ;font-size:18px;font-family:'public sans'"> A complete solution of farming <br><br></h4>
  

<div style = "background-color: RGB(46,139,87);" >
<a href="../view/Home page.php"><h2 style="color:white;font-size:20px;"><u>Home</u></h2></a>
</div>
</div>
<style>
body {
  background-image: url('../view/bank.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>

<a href="../view/Ucb.php"><h2 style="color:RGB(46,139,170);font-size:20px;" ><u>UCB Bank></u> </h2></a><br>
<a href="../view/Ucb.php"><h2 style="color:RGB(46,139,170);font-size:20px;" ><u>Dhaka Bank ></u> </h2></a><br>
<a href="../view/Ucb.php"><h2 style="color:RGB(46,139,170);font-size:20px;" ><u>Islami Bank></u> </h2></a><br>
<a href="../view/Ucb.php"><h2 style="color:RGB(46,139,170);font-size:20px;" ><u>BRAC Bank></u> </h2></a><br>
<a href="../view/Ucb.php"><h2 style="color:RGB(46,139,170);font-size:20px;" ><u>Shonali Bank></u> </h2></a><br>