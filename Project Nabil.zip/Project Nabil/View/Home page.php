<html>
<body>
<div style = "background-color: white;" >
<img src="../view/logo.jpg" height=130 style="float:left;" ><br>
<a href="login.php"><h3 style="float: right; color: RGB(46,139,87)"><br><br><br><pre>Login   </h3></a>
<br><h1 style= "color: cmyk(0,0,0,1);font-size:30px;font-family:'public sans'"> <b>AGRICULTURAL GAIN </b> </h1>
<h4 style= "color:RGB(105,105,105) ;font-size:18px;font-family:'public sans'"> A complete solution of farming <br></h4>
<div style = "background-color: RGB(46,139,87);" >
<a href="Home page.php"><h2 style="color:white;font-size:20px;"><u>Home</u></h2></a>
</div>
</div>
<style>
body {
  background-image: url('../view/rice.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>

<h1 style="color:white;font-size:70px;">Welcome to Agricultural Gain</h1>
<img src="../view/cartoon.png" height=430 style="float:right;" ><br>

<div style = "background-color: white;">
<p style="color:black;font-size:20px;"><b><u> About us:</u></b><br><br> The motivation of our project is to create a digital system for farmers as the agriculture <br>
of our country is still backdated. From our project, farmers can get so many features such as <br>
agricultural loans, advice from agriculturists and veterinary doctors, can see the market price<br>
of their crops, can communicate with local agricultural centers and can see which crops will<br>
grow better in their area. For that, we have 4 users: Farmer, Buyer, Agriculturist and Admin.<br>
Buyers can buy directly from farmers, the agriculturists will give solutions to the problems<br>
of the farmers through direct communication or by answering the FAQs. The admin will help<br>
to manage the overall project and also help to mentor the market price and the transactions.<br> 
As the purpose of our project is to make farming better and smarter, that is why we have<br>
given the name of our project <b>‘Agricultural gain’.</b><br><br><br></p><br> 
</div>
<h2 style="color:white; font-size:35px;"> If you do not have any account <b> please create one :<b></h2>


<style>
    table,th,tr
    {

        border: 1px solid;
 
}
table
{
    border-collapse: collapse;
  width: 100%
}

table.center {
  margin-left: auto; 
  margin-right: auto;
}
td {
  text-align: center;
}
</style>

<table class="center">

    <tr>
        <td style="background-image:url(../view/Farmer.jpg);background-repeat: no-repeat;" height=400 width=400><a href="Signup.php"><h1 style="color:white;font-size:90px;"><br><br><br>Farmer</h1></a> </td>
        <td style="background-image:url(../view/smart.jpg);background-repeat: no-repeat;" height=200 width=400><a href="Agriculturist sign up.php"><h1 style="color:white;font-size:90px;"><br><br><br>Agriculturist</h1></a> </td>

</tr>
<tr>
     <td style="background-image:url(../view/Buyer.jpg);background-repeat: no-repeat;" height=200 width=400><a href="Buyer sign up.php"><h1 style="color:white;font-size:90px;"><br><br><br>Buyer</h1></a> </td>
	 <td style="background-image:url(../view/admin.jpg);background-repeat: no-repeat;" height=200 width=400><a href=""><h1 style="color:white;font-size:90px;"><br><br><br>Admin</h1></a> </td>
    
</tr>
</table>
</html>
</body>