<?php 

session_start(); 

?>
<html>
<body>
<?php
 if(isset($_POST["btnClick0"])){
	 session_unset();
	 header("Location:../View/Home page.php");
 }
 if(isset($_POST["btnClick00"])){
	 $servername="localhost";
     $username="root";
     $password="";
     $dbname="farmerdata";
	 $conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
else
{
	$q="DELETE FROM data_info where username='".$_SESSION["uname"]."'";
	session_unset();
	 header("Location:../View/Home page.php");
}
$result=$conn->query($q);
	if($result)
	  echo "data deleted";
    else
		echo "data not deleted";	
	
 }
 
?>
<div style="background-color:white">
    <a href="../view/Home page.php"><img src="../view/logo.jpg" height=130 style="float:left;" ></a>
	 <h3 style="float: right; color: RGB(46,50,87)"><br><br><br><br><a style="color: RGB(46,139,87)" href="../view/agriculturist profile.php"><?php echo "welcome,". $_SESSION["uname"] ; ?></a></h3>
	 <br><h1 style= "color: cmyk(0,0,0,1);font-size:30px;font-family:'public sans'"> <b>AGRICULTURAL GAIN </b> </h1>
    <h4 style= "color:RGB(105,105,105) ;font-size:18px;font-family:'public sans'"> A complete solution of farming <br><br></h4>
  

<div style = "background-color: RGB(46,50,160);" >
<a href="../view/Home page.php"><h2 style="color:white;font-size:20px;"><u>Home</u></h2></a>
</div>
</div>
<style>
body {
  background-image: url('../view/barley.j.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>
<br><br>

<?php
//include("F:\XAMP\htdocs\Model\Agriculturist sign up.php");
// Start the session
?>
<br><h1 style="color:White;font-size:60px;text-align: center;">Welcome</h1>
<h3 style="color:White;font-size:20px;text-align: center;">FArmers are the backbone of a nation</h1><br><br>
<div style="background-color:white">
<div style = "background-color: RGB(46,50,160);" >
<h2 style="color:white">Agriculturist's profile:</h2>
</div>
<h1><b><?php echo $_SESSION["uname"]; ?></b></h2>

Mobile Number: <?php echo  $_SESSION["num"]; ?><br> 

Address: <?php echo  $_SESSION["address"]; ?><br>
Gender: <?php echo $_SESSION["gender"]; ?><br>
Expertises: <?php echo $_SESSION["expertise"] ?>
<br><br>
<form action="../Control/Database update.php" method="post">
<input type="submit" style="background-color:RGB(46,139,87); color:white"  value="Update" name="btnClick">
</form>


<form action="#" method="post">
<input type="submit" style="background-color:RGB(46,139,87); color:white"  value="delete" name="btnClick00">
</form>
<br>
</div>

<div style="background-color:white">
<div style = "background-color: RGB(46,50,160);" >
<h2 style="color:white"><b>Select from blow </b></h2>
</div>



<a href="../Model/Products_price.php"><h2 style="color:RGB(46,50,160);font-size:20px;" ><u>See products price ></u> </h2></a><br>


<a href="../Model/faq.php"><h2 style="color:RGB(46,50,160);font-size:20px;"><u>See FAQ's Answers ></u> </h2></a><br>


<a href="../Model/Loan.php"><h2 style="color:RGB(46,50,160);font-size:20px;"><u>Take loan ></u> </h2></a><br>
<a href="../Model/Nearby farmers.php"><h2 style="color:RGB(46,50,160);font-size:20px;"><u>See nearby farmers></u> </h2></a><br>


</div>
<br><br>
</body>
</html>