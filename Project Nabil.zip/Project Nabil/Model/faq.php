<?php 

session_start(); 

?>

<html>
<body>
<div style = "background-color: white;" >
<a href="../view/Home page.php"><img src="../view/logo.jpg" height=130 style="float:left;" ></a>
<h3 style="float: right; color: RGB(46,50,160)"><br><br><a href="../view/agriculturist profile.php"><h3 style="color:RGB(46,139,87);float: right;"><u> <?php echo "welcome,". $_SESSION["uname"] ; ?></u></h3></h3></a>
<br><h1 style= "color: cmyk(0,0,0,1);font-size:30px;font-family:'public sans'"> <b>AGRICULTURAL GAIN </b> </h1>
<h4 style= "color:RGB(105,105,105) ;font-size:18px;font-family:'public sans'"> A complete solution of farming <br></h4>
<div style = "background-color: RGB(46,50,160);" >
<a href="../view/Home page.php"><h2 style="color:white;font-size:20px;"><u>Home</u></h2></a>
</div>
</div>
<style>
body {
  background-image: url('../view/fruitveg.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>
<h1 style="color:white;font-size:50px">Frequently Asked Questions </h1>
<?php
$firstQuestion =
"<?xml version='1.0' encoding='UTF-8'?>
<note>
<q1>What to do if any virus attacks the rice?</q1>
<topic>(agriculture)</topic>

</note>";
?>
<div style="background-color:white">
<div style="background-color:RGB(46,50,160)">
<h1 style="color:white;font-size:30px">
Question:
<?php
$xml=simplexml_load_string($firstQuestion) or die("Error: Cannot create object");
print_r($firstQuestion);
?>
</h1>
</div>

<?php
$firstAnswer =
"<?xml version='1.0' encoding='UTF-8'?>
<note>
<ans>The four most important strategies for rice disease management are to rotate crops, plant resistant varieties, plant in warm soil and use fungicides when necessary.
 An integrated approach that uses all of these methods is the most effective and profitable.</ans>
</note>";
?>
<b>Most Common Answer:</b><br>
<?php
$xml=simplexml_load_string($firstAnswer) or die("Error: Cannot create object");
print_r($firstAnswer);
?>
<br><br>
</div>


<?php
$secondQuestion =
"<?xml version='1.0' encoding='UTF-8'?>
<note>
<q1>What is soil health?</q1>
<topic>(agriculture)</topic>

</note>";
?>
<div style="background-color:white">
<div style="background-color:RGB(46,50,160)">
<h1 style="color:white;font-size:30px">
Question:
<?php
$xml=simplexml_load_string($secondQuestion) or die("Error: Cannot create object");
print_r($secondQuestion);
?>
</h1>
</div>

<?php
$secondAnswer =
"<?xml version='1.0' encoding='UTF-8'?>
<note>
<ans>Soil health is defined as the continued capacity of soil to function as a vital living ecosystem that sustains plants, animals, and humans. Healthy soil gives us clean air and water, bountiful crops and forests, productive grazing lands,
diverse wildlife, and beautiful landscapes.</ans>
</note>";
?>
<b>Most Common Answer:</b><br>
<?php
$xml=simplexml_load_string($firstAnswer) or die("Error: Cannot create object");
print_r($secondAnswer);
?>
<br><br>
</div>


<?php
$thirdQuestion =
"<?xml version='1.0' encoding='UTF-8'?>
<note>
<q1>What are the common insecticides?</q1>
<topic>(agriculture)</topic>

</note>";
?>
<div style="background-color:white">
<div style="background-color:RGB(46,50,160)">
<h1 style="color:white;font-size:30px">
Question:
<?php
$xml=simplexml_load_string($thirdQuestion) or die("Error: Cannot create object");
print_r($thirdQuestion);
?>
</h1>
</div>

<?php
$thirdAnswer =
"<?xml version='1.0' encoding='UTF-8'?>
<note>
<ans>The most commonly used insecticides are the organophosphates, pyrethroids and carbamates. The USDA (2001) reported that insecticides accounted for 12% of total pesticides applied to the surveyed crops.
Corn and cotton account for the largest shares of insecticide use in the United States</ans>
</note>";
?>
<b>Most Common Answer:</b><br>
<?php
$xml=simplexml_load_string($thirdAnswer) or die("Error: Cannot create object");
print_r($thirdAnswer);
?>
<br><br>
</div>


<?php
$fourthQuestion =
"<?xml version='1.0' encoding='UTF-8'?>
<note>
<q1>What is bird flu?</q1>
<topic>(poultry)</topic>

</note>";
?>
<div style="background-color:white">
<div style="background-color:RGB(46,50,160)">
<h1 style="color:white;font-size:30px">
Question:
<?php
$xml=simplexml_load_string($fourthQuestion) or die("Error: Cannot create object");
print_r($fourthQuestion);
?>
</h1>
</div>

<?php
$fourthAnswer =
"<?xml version='1.0' encoding='UTF-8'?>
<note>
<ans>Bird flu, or avian flu, is an infectious type of influenza that spreads among birds. In rare cases, it can affect humans.
 There are lots of different strains of bird flu virus. Most of them don't infect humans</ans>
</note>";
?>
<b>Most Common Answer:</b><br>
<?php
$xml=simplexml_load_string($fourthAnswer) or die("Error: Cannot create object");
print_r($fourthAnswer);
?>
<br><br>
</div>
<br><br>
</html>
</body>