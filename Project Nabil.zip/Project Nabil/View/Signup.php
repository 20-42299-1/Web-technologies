<!DOCTYPE html>
<html>
<head>
</head>
<body>
<div style="background-color:white;">
<a href="../view/Home page.php"><img src="../view/logo.jpg" height=130 style="float:left;" ></a>
<h3 style="float: right; color: RGB(46,139,87)"><br><br><br><a style="color: RGB(46,139,87)" href="../view/login.php">Already have an account?</a></h3>
<br><h1 style= "color: cmyk(0,0,0,1);font-size:30px;font-family:'public sans'"> <b>AGRICULTURAL GAIN </b> </h1>
<h4 style= "color:RGB(105,105,105) ;font-size:18px;font-family:'public sans'"> A complete solution of farming <br></h4>

<h6 style="color:white">
<?php

$cookie_name="loginCheck"; 
$cookie_value="1";   
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
if (!isset($_COOKIE['count'])) { 
  echo "Welcome! This is the first time you have viewed this page today."; 
  $cookie = 1;
  setcookie("count", $cookie);
}
else
{
  $cookie = ++$_COOKIE['count'];
  setcookie("count", $cookie); 
  echo "You have viewed this page today ".$_COOKIE['count']." times.";
};

?>
<?php
$isPost=false;
$uname="";
if(isset($_POST["btnClick"]))
{
	$isPost=true;
	if($_POST["uname"]!="")
		$username=$_POST["uname"];
	//echo "button clicked";
}
$password="";
if(isset($_POST["btnClick"]))
{
	$isPost=true;
	if($_POST["pass"]!="")
		$password=$_POST["pass"];
	//echo "button clicked";
}
$mobilenumber="";
if(isset($_POST["btnClick"]))
{
	$isPost=true;
	if($_POST["num"]!="")
		$password=$_POST["num"];
	//echo "button clicked";
}

$gender="";
if(isset($_POST["btnClick"]))
{
	$isPost=true;
	if($_POST["gender"]!="")
		$radio=$_POST["gender"];
	//echo "button clicked";
}
$expertise="";
if(isset($_POST["btnClick"]))
{
	$isPost=true;
	if($_POST["expertise"]!="")
		$radio=$_POST["expertise"];
	//echo "button clicked";
}
$address="";
if(isset($_POST["btnClick"]))
{
	$isPost=true;
	if($_POST["address"]!="")
		$radio=$_POST["address"];
	//echo "button clicked";
}
?>
</h6> 
<div >
   
    <br>
   <center> <h1 style="color:rgb(0,0,0)">Welcome</center>
   <center><p style="color:rgb(70,60,120)">Farmers are the backbone of a nation</center>
   
</div>
<style>
body {
  background-image: url('Farmer sign.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>
<center>
<form action="#" method="post">
Username:<input type="text" id="uname" name="uname">
<?php
if($isPost==true && $uname=="")
 echo "<span style='color:red;'>Required</span>";
?>
<br><br>
Password:<input type="password" id="pass" name="pass">
<?php
if($isPost==true && $password=="")
 echo "<span style='color:red;'>Required</span>";
?>
<br><br>
Mobile Number:<input type="number" id="num" name="num">
<?php
if($isPost==true && $mobilenumber=="")
 echo "<span style='color:red;'>Required</span>";
?>
<br><br>
Gender:<input type="radio" name="gender" value="Male">Male
<input type="radio" name="gender" value="Female">Female
<input type="radio" name="gender" value="Others">Others
<?php
if($isPost==true && $gender=="")
 echo "<span style='color:red;'>Select one</span>";
?>
<br><br>
Expertise:<input type="checkbox" name="expertise[]" value="Farming">Farming
<input type="checkbox" name="expertise[]" value="Fishing">Fishing
<input type="checkbox" name="expertise[]" value="CowBoy">Cow-Boy
<input type="checkbox" name="expertise[]" value="shepherd">Shepherd
<?php
if($isPost==true && $expertise=="")
 echo "<span style='color:red;'>Select one</span>";
?>
<br><br>
Address:<textarea name="address" rowspan="3" colspan="30"></textarea>
<?php
if($isPost==true && $address=="")
 echo "<span style='color:red;'>Required</span>";
?>
<br><br>
<input type="submit" value="Click" name="btnClick">
</form>
</center>

<h6 style="font-size=0px">
<?php
//storing sector array to a variable
$work="";	//array varible
$txt4_2 =$_POST["expertise"] ;
 foreach ($txt4_2 as $expertise){
 
   $work=$work." ".$expertise;
}
?>
<?php	
session_start();
if($_POST["uname"]!="" && $_POST["num"]!="" && $_POST["pass"]!="" && $_POST["gender"]!="" && $_POST["expertise"]!="" && $_POST["address"]!="")
{
$_SESSION["uname"] = $_POST["uname"];
$_SESSION["pass"] = $_POST["pass"];
$_SESSION["num"] = $_POST["num"];
$_SESSION["gender"] = $_POST["gender"];
$_SESSION["expertise"] = $work;
$_SESSION["address"] = $_POST["address"];
	header("Location:farmerpage.php");
	$crdata=file_get_contents('../Model/Infor.json');   //Json Write
    $ar_data=json_decode($crdata,true);
    $put=array(				
        'user'=>$_POST["uname"],
        'pw'=>$_POST["pass"],    
        'gender'=>$_POST["gender"],
        'address'=>$_POST["address"],
		'expertise'=>$_POST["expertise"],
		'num'=>$_POST["num"],
       
    );
    $ar_data[]=$put;								//Put array in JSON file
    $final_data=json_encode($ar_data);
    file_put_contents('../Model/Infor.json',$final_data);
	
	$myfile = fopen("../Model/farmers data.txt", "a") or die("Unable to open file!");
$txt =$_POST["uname"];
fwrite($myfile, "Username: ");	//Txt write
fwrite($myfile, $txt);
fwrite($myfile, " ");


$txt3 =$_POST["pass"] ;
fwrite($myfile, "Password: ");
fwrite($myfile, $txt3);
fwrite($myfile, " ");

$txt4 =$_POST["gender"] ;
fwrite($myfile, "Gender: ");
fwrite($myfile, $txt4);
fwrite($myfile, " ");

$txt4_1 =$_POST["expertise"] ;
fwrite($myfile, "Expertise: ");
foreach ($txt4_1 as $expertise){
	fwrite($myfile, $expertise);
	fwrite($myfile, " ");
}


$txt5 =$_POST["num"] ;
fwrite($myfile, "Mobile Number: ");
fwrite($myfile, $txt5);
fwrite($myfile, " ");

$txt6 =$_POST["address"] ;
fwrite($myfile, "Address: ");
fwrite($myfile, $txt6);
fwrite($myfile, " ");


fclose($myfile); 
   
}

//database insertion part : agriculturist_info
$servername="localhost";
$username="root";
$password="";
$dbname="farmerdata";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
else
{
	echo "Successful connection";
	$q="INSERT INTO data_info(username,Password,Gender,Expertise,Mobilenumber,Address) VALUES('".$_POST["uname"]."','".$_POST["pass"]."','".$_POST["gender"]."','".$work."','".$_POST["num"]."','".$_POST["address"]."')";

	$result=$conn->query($q);
	if($result)
	  echo "data inserted";
    else
		echo "data not inserted";	
}

//database insertion part : all_info
$servername="localhost";
$username="root";
$password="";
$dbname="all";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
else
{
	echo "Successful connection";
	$q="INSERT INTO all_info(username,Password,userType) VALUES('".$_POST["uname"]."','".$_POST["pass"]."','farmer')";

	$result=$conn->query($q);
	if($result)
	  echo "data inserted";
    else
		echo "data not inserted";	
}
?>  
</h6>
</div>
</h6>
<br>
</body>
</html>