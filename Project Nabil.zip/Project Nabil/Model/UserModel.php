<?php
function Login($username,$password)
{
	session_start();

$servername="localhost";
$username="root";
$password="";
$dbname="all";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
else
{
	
	$q="SELECT * FROM all_info where username='".$uname."' and Password='".$password."'";
	$result=$conn->query($q);
	if($result->num_rows>0)
	{
		while($row=$result->fetch_assoc())
		{
		
		 $_SESSION["userType"]=$row["userType"];
		
		}
		if($_SESSION["userType"]=='farmer'){
			$dbname="farmerdata";
			$conn=new mysqli($servername,$username,$password,$dbname);
			if($conn->connect_error)
			{
				die("Connection failed:".$conn->connect_error);
			}
		else
		{
	
		  $q="SELECT * FROM data_info where username='".$uname."' and Password='".$password."'";
		  $result=$conn->query($q);
		  if($result->num_rows>0)
		  {
			while($row=$result->fetch_assoc())
			{
			
		
			$_SESSION["num"] = $row["Mobilenumber"];
			$_SESSION["gender"] = $row["Gender"];
			$_SESSION["address"] = $row["Address"];
			$_SESSION["expertise"] = $row["Expertise"];
		
			}
			 return true;
		  }
	    }
	}
	else
	{
	 return false;	
	}
 }
}
}
?>