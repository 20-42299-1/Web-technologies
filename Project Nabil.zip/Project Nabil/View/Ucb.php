<?php
$isPost=false;
$loan="";
if(isset($_POST["btnClick"]))
{
	$isPost=true;
	if($_POST["loan"]!="")
		$username=$_POST["loan"];
	//echo "button clicked";
}
$deposit="";
if(isset($_POST["btnClick"]))
{
	$isPost=true;
	if($_POST["deposit"]!="")
		$username=$_POST["deposit"];
	//echo "button clicked";
}
?>
<div >
   
    <br>
   <center> <h1 style="color:rgb(0,0,0)">Welcome</center>
   <center><p style="color:rgb(70,60,120)">Farmers are the backbone of a nation</center>
   
</div>
<style>
body {
  background-image: url('Farmer sign.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>
<center>
<form action="#" method="post">
Loan amount:<input type="number" id="loan" name="loan">
<?php
if($isPost==true && $loan=="")
 echo "<span style='color:red;'>Required</span>";
?>
<br><br>
Deposit amount:<input type="number" id="deposit" name="deposit">
<?php
if($isPost==true && $deposit=="")
 echo "<span style='color:red;'>Required</span>";
?>
<br><br>
<input type="submit" value="Click" name="btnClick">
</form>
</center>