<?php
$servername="localhost";
$username="root";
$password="";
$dbname="farmerdata";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
else
{
	$q="SELECT * from data_info";
	$result=$conn->query($q);
	$output='<table border="1" width=100%><tr><th>Username</th><th>Email</th><th>Gender</th><th>Expertizes</th><th>Institute</th></tr>';
	if($result->num_rows>0)
	{
		while($row=$result->fetch_assoc())
		{
			$output.= "<tr><td>{$row["username"]}</td><td>{$row["Mobilenumber"]}</td><td>{$row["Gender"]}</td><td>{$row["Expertise"]}</td><td>{$row["Address"]}</td></tr>";
		}
		$output.='</table>';
	}
	else
		echo "O results";
	
	
}
$conn->close();
echo $output;
?>
